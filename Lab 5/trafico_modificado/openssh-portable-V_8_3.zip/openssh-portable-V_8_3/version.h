/* $OpenBSD: version.h,v 1.87 2020/05/06 20:58:01 djm Exp $ */

#define SSH_VERSION	"OpenSSH_8.3"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
